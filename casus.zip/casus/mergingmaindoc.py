import tkinter as tk
from tkinter import ttk, messagebox, Text, Canvas, Menu, Toplevel, Label
from tkinter import *
import json
from PIL import ImageTk, Image
import qrcode


def haal_huisregels_op():
    json_path = "casus/huisregels.json"
    try:
        with open(json_path, 'r', encoding='utf-8') as json_file:
            data = json.load(json_file)
            return data.get('regels', [])
    except FileNotFoundError:
        print("Het opgegeven JSON-bestand is niet gevonden.")
        return []
    except Exception as e:
        print("Error reading JSON:", e)
        return []


class HuisregelsApp(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title("Huisregels")
        self.huisregels = haal_huisregels_op()

        self.label = tk.Label(self, text="Huisregels")
        self.label.pack(pady=5)
        self.text_widget = tk.Text(
            self, height=20, width=60, state=tk.DISABLED)
        self.text_widget.pack()
        self.display_huisregels()

    def display_huisregels(self):
        try:
            self.text_widget.config(state=tk.NORMAL)
            if self.huisregels:
                for regel in self.huisregels:
                    self.text_widget.insert(tk.END, f" - {regel}\n")
            else:
                self.text_widget.insert(tk.END, "Geen huisregelsgevonden.")
            self.text_widget.config(state=tk.DISABLED)

        except Exception as e:
            print("Error:", e)


class QRcodeApp(tk.Toplevel):
    def __init__(self, data_to_encode=None, master=None):
        super().__init__(master)
        self.title("QR code")
        self.data_to_encode = data_to_encode
        self.qrcode_image_path = self.generate_qr_code()
        self.label = tk.Label(self, text="Qr code")
        self.label.pack(pady=5)

        self.image_reference = ImageTk.PhotoImage(file=self.qrcode_image_path)

        self.image_label = tk.Label(self)
        self.image_label.pack()
        self.image_label.config(image=self.image_reference)

    def generate_qr_code(self):
        # Maak een QR-code-object
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )

        # Voeg de gegevens toe aan de QR-code
        qr.add_data(self.data_to_encode)
        qr.make(fit=True)

        # Maak een afbeelding van de QR-code met de PIL Image-module
        img = qr.make_image(fill_color="black", back_color="white")

        # Toon de QR Code
        img_path = "qr_code.png"
        img.save(img_path)

        return img_path


class ParkeerbeheerApp(tk.Toplevel):
    def __init__(self):
        self.parkeer_data = self.laad_parkeerinformatie()

    def laad_parkeerinformatie(self):
        try:
            with open('casus/parkeer.json', 'r') as file:
                return json.load(file)
        except FileNotFoundError:
            return []

    def opslag_parkeerinformatie(self):
        with open('casus/parkeer.json', 'w') as file:
            json.dump(self.parkeer_data, file)

    def add_parkeerplaats(self, plaats, beschikbare_plekken):
        self.parkeer_data.append(
            {"Plaats": plaats, "beschikbare_plekken": beschikbare_plekken})
        self.opslag_parkeerinformatie()

    def wijzig_parkeerplaats(self, plaats, nieuwe_beschikbare_plekken):
        for info in self.parkeer_data:
            if info["Plaats"] == plaats:
                info["beschikbare_plekken"] = nieuwe_beschikbare_plekken
                self.opslag_parkeerinformatie()
                print(
                    f"Informatie voor {plaats} is gewijzigd naar {nieuwe_beschikbare_plekken} beschikbare plekken.")
                return

        print(f"Plaats {plaats} niet gevonden. Wijziging mislukt.")

    def verwijder_parkeerplaats(self, plaats):
        for info in self.parkeer_data:
            if info["plaats"] == plaats:
                self.parkeer_data.remove(info)
                self.opslag_parkeerinformatie()
                print(f"Informatie voor {plaats} is verwijderd.")
                return

        print(f"Plaats {plaats} niet gevonden. Verwijdering mislukt.")

    def krijg_parkeerinformatie(self):
        return self.parkeer_data


def haal_timetable_op():
    try:
        with open('casus/timetable.json', 'r') as json_bestand:
            data = json.load(json_bestand)
            return data.get('schema', [])
    except FileNotFoundError:
        print("Het opgegeven JSON-bestand is niet gevonden.")
        return []


class TimetableApp(tk.Toplevel):
    def __init__(self, timetable_data=None, master=None):
        super().__init__(master)
        self.title("Tijdschema")
        self.timetable_data = timetable_data

        self.label = tk.Label(self, text="Tijdschema")
        self.label.pack(pady=5)
        self.text_widget = tk.Text(
            self, height=20, width=70, state=tk.DISABLED)
        self.text_widget.pack()
        self.display_timetable()

    def display_timetable(self):
        try:
            self.text_widget.config(state=tk.NORMAL)
            if self.timetable_data:
                for sessie in self.timetable_data:
                    self.text_widget.insert(
                        tk.END, f"Tijdslot: {sessie['tijdslot']}, Lokaal: {sessie['sessie']['Lokaal']}, Presentatie: {sessie['sessie']['Presentatie']}\n")
            else:
                self.text_widget.insert(tk.END, "Geen timetable gevonden.")
        except Exception as a:
            print("Error:", a)


class LokaalReserveringSysteem:
    def __init__(self):
        self.beschikbare_lokalen = {
            'b.3.301': {'reserveringen': [], 'informatie': None, 'limiet_personen': 25},
            'b.3.302': {'reserveringen': [], 'informatie': None, 'limiet_personen': 30},
            'b.3.303': {'reserveringen': [], 'informatie': None, 'limiet_personen': 30},
            'b.3.304': {'reserveringen': [], 'informatie': None, 'limiet_personen': 30},
            'b.3.305': {'reserveringen': [], 'informatie': None, 'limiet_personen': 30},
            'b.3.306': {'reserveringen': [], 'informatie': None, 'limiet_personen': 30},
            'b.3.307': {'reserveringen': [], 'informatie': None, 'limiet_personen': 30},
            'b.3.308': {'reserveringen': [], 'informatie': None, 'limiet_personen': 30},
            'b.3.309': {'reserveringen': [], 'informatie': None, 'limiet_personen': 30},
            'b.3.310': {'reserveringen': [], 'informatie': None, 'limiet_personen': 30},
        }
        self.gereserveerde_lokalen = set()

    def opslaan(self):
        with open("casus/lokalen.json", "w") as f:
            for lokaal, info in self.beschikbare_lokalen.items():
                reserveringen = ", ".join(info['reserveringen'])
                f.write(f"{lokaal}:{reserveringen}:{info['informatie']}\n")

    def laden(self):
        try:
            with open("casus/lokalen.json", "r") as f:
                self.beschikbare_lokalen = json.load(f)
                for lokaal, info in self.beschikbare_lokalen.items():
                    if lokaal not in self.gereserveerde_lokalen and info['reserveringen']:
                        self.gereserveerde_lokalen.add(lokaal)

        except FileNotFoundError:
            pass

    def reserveer_lokaal(self, lokaal, persoon, aantal_personen, informatie=None):
        if lokaal in self.beschikbare_lokalen:
            if lokaal not in self.gereserveerde_lokalen:
                self.gereserveerde_lokalen.add(lokaal)
                self.beschikbare_lokalen[lokaal]['reserveringen'].add(
                    persoon, informatie, aantal_personen)
                self.beschikbare_lokalen[lokaal]['informatie'] = informatie
                print(
                    f"Lokaal {lokaal} succesvol gereserveerd door {persoon} met informatie: {informatie}, Aantal Personen: {aantal_personen}.")
                self.opslaan()  # Sla de wijzigingen op
                return True
            else:
                print(
                    f"Lokaal {lokaal} is al gereserveerd. Dubbele reservering is niet toegestaan.")
                return False
        else:
            print(f"Lokaal {lokaal} is niet beschikbaar of al gereserveerd.")
            return False

    def wijzig_lokaal(self, lokaal, informatie):
        if lokaal in self.gereserveerde_lokalen:
            self.beschikbare_lokalen[lokaal]['informatie'] = informatie
            print(
                f"Informatie voor gereserveerd lokaal {lokaal} succesvol gewijzigd naar: {informatie}.")
            self.opslaan()  # Sla de wijzigingen op
            return True
        else:
            print(f"Lokaal {lokaal} is niet gereserveerd of niet bekend.")
            return False

    def verwijder_lokaal(self, lokaal):
        if lokaal in self.gereserveerde_lokalen:
            self.gereserveerde_lokalen.remove(lokaal)
            self.beschikbare_lokalen[lokaal]['reserveringen'] = set()
            self.beschikbare_lokalen[lokaal]['informatie'] = None
            self.opslaan()  # Sla de wijzigingen op
            print(f"Lokaal {lokaal} succesvol verwijderd.")
            return True
        else:
            print(f"Lokaal {lokaal} is niet gereserveerd of niet bekend.")
            return False

    def toon_beschikbare_lokalen(self):
        print("Beschikbare lokalen:")
        for lokaal, info in self.beschikbare_lokalen.items():
            print(
                f"{lokaal}: {info['reserveringen']}, Informatie: {info['informatie']}")

    def toon_gereserveerde_lokalen(self):
        print("Gereserveerde lokalen:", self.gereserveerde_lokalen)


class MainApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Home page")
        self.parkeer_manager = ParkeerbeheerApp()
        self.lokaal_reservering = LokaalReserveringSysteem()

        menu = Menu(self)
        self.config(menu=menu)

        filemenu = Menu(menu)
        menu.add_cascade(label="Navigatie", menu=filemenu)

        filemenu.add_command(label="Huisregels", command=self.show_huisregels)
        filemenu.add_command(label="QR Code", command=self.show_qr_code)
        filemenu.add_command(label="Plattegrond",
                             command=self.show_plattegrond)
        filemenu.add_command(label="Parkeerbeheer",
                             command=self.show_parkeer_info)
        filemenu.add_command(label="Tijdschema", command=self.show_timetable)
        filemenu.add_command(label="Lokaal Reserveren",
                             command=self.show_lokaal_reserveren)

    def show_huisregels(self):
        app = HuisregelsApp(self)

    def show_qr_code(self):
        data_to_encode = "https://i1.sndcdn.com/artworks-38Pz2P2EK4ygi0A6-sIafyw-t500x500.jpg"
        app = QRcodeApp(data_to_encode)

    def show_plattegrond(self):
        photopath = "casus/eventmap.jpg"
        plattegrond_img = Image.open(photopath)
        plattegrond_img = plattegrond_img.resize((800, 800), Image.NEAREST)

        plattegrond_tk = ImageTk.PhotoImage(plattegrond_img)

        plattegrond_label = Label(self, image=plattegrond_tk)
        plattegrond_label.image = plattegrond_tk
        plattegrond_label.pack()

    def show_parkeer_info(self):
        parkeer_info_window = ParkeerbeheerWindow(self, self.parkeer_manager)

    def show_timetable(self):
        timetable_data = haal_timetable_op()
        app = TimetableApp(timetable_data, self)

    def show_lokaal_reserveren(self):

        lokaal_reserveren_window = Toplevel(self)
        lokaal_reserveren_window.title("Lokaal Reserveren")

        label_lokaal = tk.Label(lokaal_reserveren_window, text="Lokaal")
        label_lokaal.grid(row=0, column=0, padx=5, pady=5)

        entry_lokaal = Entry(lokaal_reserveren_window)
        entry_lokaal.grid(row=0, column=1, padx=5, pady=5)

        label_informatie = tk.Label(
            lokaal_reserveren_window, text="Informatie")
        label_informatie.grid(row=1, column=0, padx=5, pady=5)

        entry_informatie = Entry(lokaal_reserveren_window)
        entry_informatie.grid(row=1, column=1, padx=5, pady=5)

        label_persoon = tk.Label(
            lokaal_reserveren_window, text="Persoon")
        label_persoon.grid(row=2, column=0, padx=5, pady=5)

        entry_persoon = Entry(lokaal_reserveren_window)
        entry_persoon.grid(row=2, column=1, padx=5, pady=5)

        reserveer_button = Button(
            lokaal_reserveren_window, text="Reserveer", command=lambda: self.reserveer_lokaal_gui())

        reserveer_button.grid(row=3, column=0, columnspan=2, pady=10)

        beschikbare_lokalen_button = tk.Button(
            lokaal_reserveren_window, text="Toon Beschikbare Lokalen", command=self.show_beschikbare_lokalen)
        beschikbare_lokalen_button.grid(row=4, column=0, columnspan=2, pady=10)

        gereserveerde_lokalen_button = tk.Button(
            lokaal_reserveren_window, text="Toon Gereserveerde Lokalen", command=self.show_gereserveerde_lokalen)
        gereserveerde_lokalen_button.grid(
            row=5, column=0, columnspan=2, pady=10)

    def reserveer_lokaal_gui(self):
        lokaal_reserveren_window = Toplevel(self)
        lokaal_reserveren_window.title("Lokaal Reserveren")

        label_lokaal = tk.Label(lokaal_reserveren_window, text="Lokaal")
        label_lokaal.grid(row=0, column=0, padx=5, pady=5)

        entry_lokaal = Entry(lokaal_reserveren_window)
        entry_lokaal.grid(row=0, column=1, padx=5, pady=5)

        label_informatie = tk.Label(
            lokaal_reserveren_window, text="Informatie")
        label_informatie.grid(row=1, column=0, padx=5, pady=5)

        entry_informatie = Entry(lokaal_reserveren_window)
        entry_informatie.grid(row=1, column=1, padx=5, pady=5)

        label_persoon = tk.Label(
            lokaal_reserveren_window, text="Persoon")
        label_persoon.grid(row=3, column=0, padx=5, pady=5)

        entry_persoon = Entry(lokaal_reserveren_window)
        entry_persoon.grid(row=4, column=1, padx=5, pady=5)

        reserveer_button = Button(lokaal_reserveren_window, text="Reserveer", command=lambda: self.reserveer_lokaal(
            entry_lokaal, entry_informatie))
        reserveer_button.grid(row=5, column=0, columnspan=2, pady=10)

        pass

    def reserveer_lokaal(self, entry_lokaal, entry_informatie):
        lokaal = entry_lokaal.get()
        informatie = entry_informatie.get()
        reservering_succesvol = self.lokaal_reservering.reserveer_lokaal(
            lokaal, informatie)

        if reservering_succesvol:
            messagebox.showinfo(
                "Succes", f"Lokaal {lokaal} succesvol gereserveerd met informatie: {informatie}.")
        else:
            messagebox.showerror(
                "Fout", f"Lokaal {lokaal} is niet beschikbaar of al gereserveerd.")

    def show_beschikbare_lokalen(self):
        beschikbare_lokalen_window = Toplevel(self)
        beschikbare_lokalen_window.title("Beschikbare Lokalen")

        beschikbare_lokalen_label = Label(
            beschikbare_lokalen_window, text="Beschikbare lokalen:")
        beschikbare_lokalen_label.pack()

        beschikbare_lokalen_text = Text(
            beschikbare_lokalen_window, height=10, width=100)
        beschikbare_lokalen_text.pack()

        beschikbare_lokalen_text.insert(tk.END, "Beschikbare lokalen:\n")
        for lokaal, info in self.lokaal_reservering.beschikbare_lokalen.items():
            beschikbare_lokalen_text.insert(
                tk.END, f"{lokaal}: Reserveringen: {', '.join([f'{name} ({amount}p)' for name, _, amount in info['reserveringen']])}, Informatie: {info['informatie']}, Limiet Personen: {info.get('limiet_personen', 'N/A')}\n")

    def show_gereserveerde_lokalen(self):
        gereserveerde_lokalen_window = Toplevel(self)
        gereserveerde_lokalen_window.title("Gereserveerde Lokalen")

        gereserveerde_lokalen_label = Label(
            gereserveerde_lokalen_window, text="Gereserveerde lokalen:")
        gereserveerde_lokalen_label.pack()

        gereserveerde_lokalen_text = Text(
            gereserveerde_lokalen_window, height=10, width=40)
        gereserveerde_lokalen_text.pack()

        gereserveerde_lokalen_text.insert(tk.END, "Gereserveerde lokalen:\n")
        for lokaal in self.lokaal_reservering.gereserveerde_lokalen:
            gereserveerde_lokalen_text.insert(tk.END, f"{lokaal}\n")


class ParkeerbeheerWindow(Toplevel):
    def __init__(self, master, parkeer_manager):
        super().__init__(master)
        self.title("Parkeerbeheer")
        self.parkeer_manager = parkeer_manager

        self.plaats_entry = Entry(self, width=30)
        self.beschikbare_plekken_entry = Entry(self, width=10)

        tk.Label(self, text="Plaats:").grid(
            row=0, column=0, padx=10, pady=5, sticky=tk.W)
        tk.Label(self, text="Beschikbare plekken:").grid(
            row=1, column=0, padx=10, pady=5, sticky=tk.W)

        self.plaats_entry.grid(row=0, column=1, padx=10, pady=5)
        self.beschikbare_plekken_entry.grid(row=1, column=1, padx=10, pady=5)

        tk.Button(self, text="Voeg toe", command=self.voeg_toe).grid(
            row=2, column=0, columnspan=2, pady=10)
        tk.Button(self, text="Wijzig", command=self.wijzig).grid(
            row=3, column=0, columnspan=2, pady=10)

        self.display_parkeer_info()

    def display_parkeer_info(self):
        parkeer_info = self.parkeer_manager.krijg_parkeerinformatie()
        tk.Label(self, text="Bestaande parkeerinformatie:").grid(
            row=4, column=0, columnspan=2, pady=5, sticky=tk.W)

        for i, info in enumerate(parkeer_info, start=5):
            tk.Label(self, text=f"Plaats: {info['Plaats']}, Beschikbare plekken: {info['beschikbare_plekken']}").grid(
                row=i, column=0, columnspan=2, pady=2, sticky=tk.W)

    def voeg_toe(self):
        plaats = self.plaats_entry.get()
        beschikbare_plekken = self.beschikbare_plekken_entry.get()

        if plaats and beschikbare_plekken:
            self.parkeer_manager.add_parkeerplaats(plaats, beschikbare_plekken)
            self.display_parkeer_info()
            messagebox.showinfo("Succes", "Parkeerplaats toegevoegd!")
        else:
            messagebox.showerror("Fout", "Vul alle velden in.")

    def wijzig(self):
        plaats = self.plaats_entry.get()
        nieuwe_beschikbare_plekken = self.beschikbare_plekken_entry.get()

        if plaats and nieuwe_beschikbare_plekken:
            self.parkeer_manager.wijzig_parkeerplaats(
                plaats, nieuwe_beschikbare_plekken)
            self.display_parkeer_info()
            messagebox.showinfo("Succes", "Parkeerplaats gewijzigd!")
        else:
            messagebox.showerror("Fout", "Vul alle velden in.")


if __name__ == "__main__":
    app = MainApp()
    app.mainloop()
